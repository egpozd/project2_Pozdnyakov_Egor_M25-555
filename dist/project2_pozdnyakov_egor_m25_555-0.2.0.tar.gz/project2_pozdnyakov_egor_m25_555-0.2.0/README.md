# Primitive Database

Простая консольная база данных на Python.

## Установка

```bash
pipx install primitive-dbv